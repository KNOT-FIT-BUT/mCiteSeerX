mCiteSeerX
Python API module for citeseerx.ist.psu.edu

Try it

In ./bin/example/ you can find example app using citeseerx.py module.

More informations:

https://merlin.fit.vutbr.cz/nlp-wiki/index.php/Rrs_cite_comparsion
